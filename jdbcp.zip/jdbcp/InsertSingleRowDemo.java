import java.sql.*;

public class  InsertSingleRowDemo//class name
{
	public static void main(String[] args)throws Exception
   {

	String driver="oracle.jdbc.OracleDriver";//driver type-4 driver

	String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";//jdba_url type-4 driver url

	String user="system";  //qul user_name

	String pass="abani";   //sql password

	String sql_query="insert into std124 values(1200,'hari','hyd','ameerpet')";

	Class.forName(driver); //driver lode type-4 driver

		Connection con=DriverManager.getConnection(jdbc_url,user,pass);//establish connection

		Statement st= con.createStatement();// create statement methord

		st.executeUpdate(sql_query);//send & execution sql query 

		System.out.println("Insert successfully");//process result

		con.close(); // close connection
     }
   }
  
