import java.sql.*;

public class  CreateTableDemo2//class name
{
	public static void main(String[] args)throws Exception
   {

	String driver="oracle.jdbc.OracleDriver";// type-4 driver

	String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";//jdba_url type-4 driver url

	String user="system";  //qul user_name

	String pass="system";   //sql password

	String sql_query="create table employee(ename varchar2(10),eno number(10),esal number(10),eaddr varchar2(50),edeptno number(10))";

	Class.forName(driver); //lode type-4 driver

		Connection con=DriverManager.getConnection(jdbc_url,user,pass);//establish connection

		Statement st= con.createStatement();// create statement obj

		st.executeUpdate(sql_query);//send & execution sql query 

		System.out.println("Table created successfully");//process result

		con.close(); // close connection
     }
   }
