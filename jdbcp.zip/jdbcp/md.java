//Medical project 
class Section1
{
	int docter;
	int compaunder;
	int norce;
}
class Section2

{
	int worker;
	int helper;
	int dressing;
}
class Section1




{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
