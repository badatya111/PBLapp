
class CalculateSimpleiInterest
{
	public double intersetToPay(double principal,float rate,int time){
	double interest=0.0;
	interest=(principal*time*rate)/100;
	return interest;
	}
}
public class SimpleInterest
{
	public static void main(String[] args) 
	{
		 CalculateSimpleiInterest csi= new CalculateSimpleiInterest();
		 double interest=csi.intersetToPay(1000.0,2.5f,48);
		System.out.println("Interset  :"+interest);
	}
}

 