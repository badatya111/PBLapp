import javax.servlet.*;
import java.io.*;
import java.util.*;


public class firstServlet Implements Servlet
{
	Static
	{
		System.out.println("Servlet class loading");
	}
	public FirstServlet()
	{
        System.out.println("Servlet instantiation");
	}

	public void init(Servlet config)throws Servlet Exception 
	{
		System.out.println("init() method called");
	}
	public void Service(ServletRequest req,ServletResponce resp)throws ServletException,IoExeption
	{
	    System.out.println("Service() methode called");
	    resp.setContainType("text/html");/mime type
		printWriter.out= resp.get writer();
	    out.println("<h1>ewlcome innocent advance java</h1><br/>");
        out.println("<h1>The service date and time:"+new date()+"</h1>");
	}
	public void destroy()
	{
		System.out.println("destory() method called");
	}
	public Servletconfig getServlet config()
	{
		return null;
	}
	public String getServletInfo()
	{
		return "developed by durga for very innocent adv.java student";
	}
}
