import java.sql.*;
public class DropTableDemo 
{
	public static void main(String[] args)throws Exception  
	{
		String driver="oracle.jdbc.OracleDriver";
		String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="system";
		String password="abani";
		String sql_query="drop table std123";

      class.forName(driver);
	  Connection  con= DriverManager.getConnection(jdbc_url,user,pwd);
	  Statement st = con.createStatement();
	  st.executeUpdate(sql_query);
      System.out.println("Hello World!");
	  con.close();

	}
}
