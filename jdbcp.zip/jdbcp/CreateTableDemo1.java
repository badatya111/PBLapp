import java.sql.*;

public class CreateTableDemo1
{
   public static void main(String[] args)throws Exception
	{
	   String driver="oracle:jdbc:OracleDriver";
	   String jdbc_url="Jdbc:Oracle:thin:@localhost:1521:XE";
	   String user="system";
	   String pwd="kumar";
	   String sql_query="create table employee1(eno number,ename varchar2(20),esal varchar2(10)eaddr varchar2(10))";
   Class.forName(driver);
   Connection con= DriverManager.getConnection(jdbc_url,user,pwd);
   Statement st =con.createStatement();
   st.executeUpdate(sql_query);
   System.out.println("Table create Successfully");
   con.close();
	}
}


	

