
import java.sql.*;

public class InsertTableDemo
{
public static void main(String[] args)throws Exception //exception hendelingh put
	{
  String driver="oracle.jdba.OracleDriver";
  String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";
  String user="system";
  String password="abani";
  String sql_query="insert into employees values(100,'durga',1000,'hyderbad')";

  class.forName(driver);//Driver lode and Register
  Connection con=DriverManager.getConnection(jdbc_url,user,pwd);//java applicatin to data base
  Statement st= con.createStatement();//connection Statement
  int updateCount=st.executeUpdate(sql_query);//send sql data base excute
  System.out.println("The number of row inserted:"+updateCount);
  con.close();//close connection
	}
}
