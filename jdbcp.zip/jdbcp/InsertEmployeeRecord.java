import java.sql.*;
import java.util.*;


public class InsertEmployeeRecord

{
	public static void main(String[] args)throws Exception
	{
		String driver="oracle.jdbc.OracleDriver";
	    String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="system";
		String password="kumar";

		Class.forName(driver);

		Connection con=DriverManager.getConnection(jdbc_url,user,password);
		Statement st =con.createStatement();
		
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter The Employee Name");
			String ename=sc.next();
			System.out.println("Enter The Employee Number");
			int eno=sc.nextInt();
			System.out.println("Enter The Employee salary");
			double esal=sc.nextDouble();
			System.out.println("Enter The Employee Address");
			String eaddre=sc.next();
			System.out.println("Enter The Employee Depeartment");
			String edept=sc.next();

			String sql_Query=String.format("insert into employee values('%s',%d,%f,'%s','%s')",ename,eno,esal,eaddre,edept);
			st.execute(sql_Query);
			System.out.println("Record successfully");
			System.out.println("Do you want to insert Record [Yes/No]");
			String option=sc.next();
			if(option.equalsIgnoreCase("No"))
			{
				break;
			}
		}
		con.close();
	}
}
