import java.sql.*;
import java.util.*;
public class MultipleRowDemo
{
    public static void main(String[] args)throws Exception
{
String driver="oracle.jdbc.OracleDriver";
String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";
String user="system";
String password="abani";
//call the driver type-4 Driver manager
Class.forName(driver);
Connection con= DriverManager.getConnection(jdbc_url,user,password);
Statement st=con.createStatement();
Scanner sc=new Scanner(System.in);//user give input
//while loop started beacuse we added rcoed then once agani added record 
while(true)
{
	//Added value in student table
	System.out.println("Enter The Std Number");
	int stdno=sc.nextInt();
	System.out.println("Enter The Std Name");
	String stdname=sc.next();
	System.out.println("Enter The Std Loc");
	String stdloc=sc.next();
	System.out.println("Enter The Std Address");
	String stdadd=sc.next();
	//scnnect sql querry DB
	String sqlQuery=String.format("insert into std124 values(%d,'%s','%s','%s')",stdno,stdname,stdloc,stdadd);
   //Execute sql queru
	st.executeUpdate(sqlQuery);
   //Show Result
	System.out.println("insert successfully");
	System.out.println("Do u want one more add record[yes/No]");
	//Option created
	String option=sc.next();
	//if condition started either yes or no
	if(option.equalsIgnoreCase("No"))
	{
		break;// suppse u want yes the add record statement, if u want to no the break and stope 
	}
  }
    con.close();//Connection closed
	}
}