package PreparedStatement;
import java.sql.*;
import java.util.*;


public class PsDemo1 
{
	public static void main(String [] args)throws Exception
	{
		String driver="oracle.jdbc.OracleDriver";
		
		String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="system";
		String password="system";

	    Class.forName(driver);
		Connection con=DriverManager.getConnection(jdbc_url,user,password);
		String sqlQuery="insert into empl values(?,?,?,?)";
		PreparedStatement pst=con.prepareStatement(sqlQuery);
		 Scanner sc=new Scanner(System.in);
		 while(true)
		{
			 System.out.println("Employee Number:");
			 int eno=sc.nextInt();
			 System.out.println("Employee Name:");
			 String ename=sc.next();
			 System.out.println("Employee job");
			 String job=sc.next();
			 System.out.println("Employee Salary");
			 int sal=sc.nextInt();

			 pst.setInt(1,eno);
			 pst.setString(2,ename);
			 pst.setString(3,job);
			 pst.setInt(4,sal);
			 pst.executeUpdate();
			 System.out.println("Record Inserted Successfully");
			 System.out.println("Do u want to Insert One more record[Yes/No]:");
			 String option=sc.next();
			 if(option.equalsIgnoreCase("No"))
			{
				 break;
			}
		}
		con.close();
	}
}
	