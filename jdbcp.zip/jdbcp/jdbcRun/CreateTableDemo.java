import java.sql.*;

public class  CreateTableDemo//class name
{
	public static void main(String[] args)throws Exception
   {

	String driver="oracle.jdbc.OracleDriver";// type-4 driver

	String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";//jdba_url type-4 driver url

	String user="system";  //qul user_name

	String pass="kumar";   //sql password

	String sql_query="create table std128(stdno number,stdname varchar2(20),stdloc varchar2(20),eaddrs varchar2(50))";

	Class.forName(driver); //lode type-4 driver

		Connection con=DriverManager.getConnection(jdbc_url,user,pass);//establish connection

		Statement st= con.createStatement();// create statement obj

		st.executeUpdate(sql_query);//send & execution sql query 

		System.out.println("Table created successfully");//process result

		con.close(); // close connection
     }
   }
