
import java.sql.*;
import java.util.*;

public class LoginType
{
	public static void main(String [] args)throws Exception
	{
		String driver="oracle.jdbc.OracleDriver";
		String jdbc_url=("jdbc:oracle:thin:@localhost:1521:ex");
		String user="system";
		String password="system";

		Class.forName(driver);
		Connection con=DriverManager.getConnection(jdbc_url,user,password);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter uid");
		//Slendrena
		String uname=sc.next();
		System.out.println("Enter password");
		//Slendrena
		String pwd=sc.next();

		String sqlQuery="select count(*) from user where uname=? and password";

		PreparedStatement ps=con.prepareStatement(sqlQuery);

		ps.setString(1,user);

		ps.setString(2,pwd);

		ResultSet rs=ps.executeQuery();
		int x=0;
		if(rs.next())
		{
			x=rs.getInt(1);
		}
		if(x==0)
		
			System.out.println("Invalid");
		
		else

			System.out.println("Valid");
			con.close();
		}
	}
