package com.wipro.bank.main;
import java.util.Scanner;

import com.wipro.bank.service.BankService;
public class MainClass {
	public static void main(String a[]) {
float principal;
int tenure;
int age;
String gender;
Scanner sc= new Scanner(System.in);
System.out.println("Enter amount");
principal=sc.nextFloat();
System.out.println("enter tenure");
tenure=sc.nextInt();
System.out.println("enter age");
age=sc.nextInt();
System.out.println("enter gender");
gender=sc.next();
BankService bs= new BankService();
bs.calculate(principal, tenure, age, gender);
	}

}
