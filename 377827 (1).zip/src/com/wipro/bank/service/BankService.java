package com.wipro.bank.service;
import com.wipro.bank.acc.*;
import com.wipro.bank.exception.*;

public class BankService {
	public String validateData(float principal, int tenure,int age, String gender)
	{
		String status="";
	int count =0;
		try{
			if(principal==0 || tenure==0 || age==0 || gender=="null")
			{
				throw new BankValidationException();
			}
			if(principal<500)
			{
				status="Invalid Principal";
				count++;
			}
			if(tenure==5 || tenure==10)
			{
				
			}
			else
			{
				status="Invalid Tenure";
			count++;
			}
			if(age<0 || age>100)
			{
				status="Invalid Age";
				count++;
			}
			if((gender.equalsIgnoreCase("female")) || (gender.equalsIgnoreCase("male")))
			{
				
			}
			else{
				status="Invalid Gender";
				count++;
			}
			if(count==0)
			{
				status="Passed";
			}
		}
		catch(BankValidationException e)
		{
			System.out.println(e);
		}
		return status;
	}
	
	public void calculate(float principal, int tenure, int age, String gender)
	{
		if(validateData(principal,tenure,age,gender).equals("Passed"))
		{RDAccount rd= new RDAccount(tenure,principal);
		rd.setInterest(age,gender);
		float i=rd.calculateInterest();
		System.out.println(i);
		float a=rd.calculateAmountDeposited();
		System.out.println(a);
		float b=rd.calculateMaturityAmount(a,i);
		System.out.println(b);
		
	}
}
}
