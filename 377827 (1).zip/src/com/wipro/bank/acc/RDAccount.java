package com.wipro.bank.acc;
public class RDAccount extends Account {
	
	public RDAccount(int tenure, float principal) {
		this.tenure = tenure;
		this.principal = principal;
	}
	
	public float calculateAmountDeposited() {
		return principal*tenure*12;
	}

	
	public float calculateInterest() {
		float r=rateOfInterest/100;
		float n=4;
		float totali=0.0f;
		for(float m=tenure*12;m>0;m--)
		{
			float t=m/12;
			float p=(float)Math.pow(1+r/n,n*t);
			totali=totali+principal*(p-1);
		}
		return totali;
	}

	
	
	
}
