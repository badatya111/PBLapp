package com.wipro.JUnit;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest1 {

	@Test
	public void testAddition() {
		Calculator c=new Calculator();
		assertEquals(5, c.addition(2, 3));
	}

	@Test
	public void testSubstraction() {
		Calculator c=new Calculator();
		assertEquals(4, c.substraction(7, 3));
	}

}
