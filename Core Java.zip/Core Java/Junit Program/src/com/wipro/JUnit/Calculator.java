package com.wipro.JUnit;

public class Calculator {
	
	public int addition(int x,int y)
	{
		return x+y;
	}
	public int substraction(int x,int y)
	{
		return x-y;
	}
	

}
