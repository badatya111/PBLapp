import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;


public class JuntPro2Test {

	@Test
	public void test() {
		ArrayList a1=new ArrayList();
		a1.add("kumar");
		a1.add("sumen");
		a1.add("rahul");
		JuntPro2 jp1 =new JuntPro2();
		assertEquals("result","FOUND",jp1.findName(a1,"kumar"));
		
		
		
	}

}
