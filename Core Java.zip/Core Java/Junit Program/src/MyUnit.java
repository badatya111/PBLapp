public class MyUnit {
	
	public String  stringConcat(String str1 ,String str2 )
	{
		
	
	return str1.concat(str2);
	
	}

	
	}
