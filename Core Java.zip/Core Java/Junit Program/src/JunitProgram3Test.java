import static org.junit.Assert.*;

import org.junit.Test;


public class JunitProgram3Test {

	@Test
	public void test() {
		JunitProgram3 jp3=new JunitProgram3();
		assertTrue(jp3.palindromeCheck("mom"));
		assertFalse(jp3.palindromeCheck("suno"));
		
		
		
	}

}
