
public class JunitProgram3 {
	
	boolean palindromeCheck(String str1)
	{
		StringBuffer str2=new StringBuffer(str1);
		StringBuffer str3=new StringBuffer();
		str3=str2.reverse();
		String str4=str3.toString();
		if(str1.equalsIgnoreCase(str4)){
			return true;
		}
		else
		{
			return false;
		}
	}

}
