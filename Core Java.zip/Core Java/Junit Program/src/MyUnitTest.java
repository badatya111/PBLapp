import static org.junit.Assert.*;

import org.junit.Test;


public class MyUnitTest {

	@Test
	public void test() {
		MyUnit m=new MyUnit();
		assertEquals(null,"kumarBadatya",m.stringConcat("kumar", "Badatya"));
		
	
		
	}

}
