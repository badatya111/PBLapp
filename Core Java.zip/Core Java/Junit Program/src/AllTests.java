import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({ JunitProgram3Test.class, JuntPro2Test.class, MyUnitTest.class })
public class AllTests {

}
