	
	import java.util.Scanner;
	
	
	abstract class Account
	{
		double int_Rate,amt;
		abstract double cal_Interest();
	}
	class CalInterestException extends Exception
	{
		public String toString()
		{
			return "Exception in Calculating Interest";
		}
	}
	class FDAccount extends Account
	{
		int days;
		int age;
		double intr;
		FDAccount(int a,int b,double c)
		{
			days=a;
			amt=b;
			int_Rate=c;
		}
		double cal_Interest()
		{
			intr=(amt*int_Rate)/100;
			return intr;
		}
	}
	class SBAccount extends Account
	{
		double intr;
		SBAccount(int a,double b)
		{
			amt=a;
			int_Rate=b;
		}
		double cal_Interest()
		{
			intr=(amt*int_Rate)/100;
			return intr;
		}
	}
	class RDAccount extends Account
	{
		int months;
		int m_amt;
		double intr;
		RDAccount(int a,int b,double c)
		{
			months=a;
			m_amt=b;
			int_Rate=c;
		}
		double cal_Interest()
		{
			intr=(m_amt*int_Rate)/100;
			return intr;
		}
	}
	public class MiniProjectAb 
	{
		public static void main(String[] args) throws CalInterestException
		{
			int x1,x2,y,z;
			double r;
			Scanner sc=new Scanner(System.in);
			Account acc;
			do
			{	
				System.out.println("\nSelect an Option :\n1.Interest Calculator-SB");
				System.out.println("2.Interest Calculator-FD\n3.Interest Calculator-RD\n4.Exit");
				x1=sc.nextInt();
				switch(x1)
				{
					case 1:
						System.out.println("In SBAccount");
						System.out.println("Enter the Account Type :");
						System.out.println("1.Normal\n2.NRI");
						x2=sc.nextInt();
						switch(x2)
						{
							case 1:
								System.out.println("\nEnter the Amount : ");
								try
								{
									y=sc.nextInt();r=4;
									if(y<0)
									{
										throw new CalInterestException();
									}
									else
									{
										acc=new SBAccount(y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
								}
								catch(CalInterestException e)
								{
									System.out.println(e+"\nAmount cannot be Negative");
								}
								break;
							case 2:
								System.out.println("\nEnter the Amount : ");
								try
								{
									y=sc.nextInt();r=6;
									if(y<0)
									{
										throw new CalInterestException();
									}
									else
									{
										acc=new SBAccount(y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
								}
								catch(CalInterestException e)
								{
									System.out.println(e+"\nAmount cannot be Negative");
								}
								break;
							default :
								System.out.println("\nInvalid Choice!!");
								break;
						}
						break;
					case 2:
						System.out.println("\nIn FDAccount");
						System.out.println("Enter the Amount,Age and Days : ");
						try
						{
							y=sc.nextInt();x2=sc.nextInt();z=sc.nextInt();
							if(y<0)
							{
								throw new CalInterestException();
							}
							else if(0<=y && y<10000000)
							{
								System.out.println("\nAmount less than 1 crore");
								if(x2<18)
								{
									throw new CalInterestException();
								}
								else if(18<=x2 && x2<60)
								{
									System.out.println("\nGeneral");
									if(z<7 || z>365)
									{
										throw new CalInterestException();
									}
									else if(6<z && z<15)
									{
										r=4.50;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(14<z && z<30)
									{
										r=4.75;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(29<z && z<46)
									{
										r=5.50;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(45<z && z<61)
									{
										r=7.00;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(60<z && z<185)
									{
										r=7.50;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(184<z && z<366)
									{
										r=8.00;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
								}
								else
								{
									System.out.println("\nSenior Citizen");
									if(z<7 || z>365)
									{
										throw new CalInterestException();
									}
									else if(6<z && z<15)
									{
										r=5.00;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(14<z && z<30)
									{
										r=5.25;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(29<z && z<46)
									{
										r=6.00;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(45<z && z<61)
									{
										r=7.50;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(60<z && z<185)
									{
										r=8.00;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(184<z && z<366)
									{
										r=8.50;
										acc=new FDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
								}
							}
							else
							{
								System.out.println("\nAmount 1 crore or more than 1 crore");
								if(z<7 || z>365)
								{
									throw new CalInterestException();
								}
								else if(6<z && z<15)
								{
									r=6.50;
									acc=new FDAccount(z,y,r);
									System.out.println("\nInterest Amount : "+acc.cal_Interest());
								}
								else if(14<z && z<30)
								{
									r=6.75;
									acc=new FDAccount(z,y,r);
									System.out.println("\nInterest Amount : "+acc.cal_Interest());
								}
								else if(29<z && z<46)
								{
									r=6.75;
									acc=new FDAccount(z,y,r);
									System.out.println("\nInterest Amount : "+acc.cal_Interest());
								}
								else if(45<z && z<61)
								{
									r=8.00;
									acc=new FDAccount(z,y,r);
									System.out.println("\nInterest Amount : "+acc.cal_Interest());
								}
								else if(60<z && z<185)
								{
									r=8.50;
									acc=new FDAccount(z,y,r);
									System.out.println("\nInterest Amount : "+acc.cal_Interest());
								}
								else if(184<z && z<366)
								{
									r=10.00;
									acc=new FDAccount(z,y,r);
									System.out.println("\nInterest Amount : "+acc.cal_Interest());
								}
							}
						}
						catch(CalInterestException e)
						{
							System.out.println(e+"\nAmount cannot be Negative\nAge should be at least 18");
							System.out.println("Days should range between 7 to 365,i.e,1 year");
						}
						break;
					case 3:
						System.out.println("\nIn RDAccount");
						System.out.println("Enter the Amount,Age & Months : ");
						try
						{
							y=sc.nextInt();x2=sc.nextInt();z=sc.nextInt();
							if(y<0)
							{
								throw new CalInterestException();
							}
							else
							{
								if(x2<18)
								{
									throw new CalInterestException();
								}
								else if(18<=x2 && x2<60)
								{
									System.out.println("\nGeneral");
									if(z<1 || z>21)
									{
										throw new CalInterestException();
									}
									else if(0<z && z<7)
									{
										r=7.50;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(6<z && z<10)
									{
										r=7.75;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(9<z && z<13)
									{
										r=8.00;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(12<z && z<16)
									{
										r=8.25;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(15<z && z<19)
									{
										r=8.50;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(18<z && z<22)
									{
										r=8.75;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
								}
								else
								{
									System.out.println("\nSenior Citizen");
									if(z<1 || z>21)
									{
										throw new CalInterestException();
									}
									else if(0<z && z<7)
									{
										r=8.00;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(6<z && z<10)
									{
										r=8.25;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(9<z && z<13)
									{
										r=8.50;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(12<z && z<16)
									{
										r=8.75;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(15<z && z<19)
									{
										r=9.00;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
									else if(18<z && z<22)
									{
										r=9.25;
										acc=new RDAccount(z,y,r);
										System.out.println("\nInterest Amount : "+acc.cal_Interest());
									}
								}
							}
						}
						catch(CalInterestException e)
						{
							System.out.println(e+"\nAmount cannot be Negative\nAge should be at least 18");
							System.out.println("Months should range between 1 to 21");
						}
						break;
					case 4:
						System.out.println("\nExit");
						break;
					default :
						System.out.println("\nInvalid Option!!");
						break;
				}
			}while(x1!=4);
		}
	}

