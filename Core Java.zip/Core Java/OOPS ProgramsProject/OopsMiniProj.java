
public class OopsMiniProj {
	
	public static void main(String args[]) {
		VideoStore1 store = new VideoStore1();

		try {
			String vtitle1 = "The Matrix";
			String vtitle2 = "Godfather II";

			store.addVideo(vtitle1);
			store.addVideo(new Video1(vtitle2));

			Video1 video = new Video1("Start Wars Episode IV : A new Hope");
			store.addVideo(video);

			store.recieveRating(vtitle1, 5);
			store.recieveRating(vtitle1, 3);
			store.recieveRating(vtitle1, 4);
			store.recieveRating(vtitle1, 3);
			store.recieveRating(vtitle1, 4);
			store.recieveRating(vtitle1, 2);
			
			store.recieveRating(vtitle2, 3);
			store.recieveRating(vtitle2, 3);
			store.recieveRating(vtitle2, 5);
			store.recieveRating(vtitle2, 3);
			store.recieveRating(vtitle2, 4);
			store.recieveRating(vtitle2, 4);

			store.checkOutVideo(vtitle1);
			
			store.recieveRating(video.getTitle(), 4);
			store.recieveRating(video.getTitle(), 3);
			store.recieveRating(video.getTitle(), 2);
			store.recieveRating(video.getTitle(), 4);
			store.recieveRating(video.getTitle(), 3.5);
			store.recieveRating(video.getTitle(), 5);
			
			 
			store.listInventory();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}

class Video1 {

	private static int count = -1;
	private int index = -1;
	private String title;
	private boolean checked;
	private double userRatings;
	private int noOfRatings;

	public Video1() {
		if (this.index < 0)
			this.index = ++count;

	}

	public Video1(String title) {
		if (this.index < 0)
			this.index = ++count;

		this.title = title;
		checked = false;
		userRatings = 0;
		noOfRatings = 0;
	}

	public int getIndex() {
		return this.index;
	}

	public int getSL() {
		return this.index + 1;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitle() {
		return this.title;
	}

	public String getShortTitle() {
		if(this.title.length() >= 28){
			return (this.title.substring(0, 25) + "...");
		}
		return this.title;
	}

	public void beingChecked() {
		this.checked = true;
	}

	public void beingReturned() {
		this.checked = false;
	}

	public boolean isChecked() {
		return this.checked;
	}

	public String getStatus() {
		if (this.checked) {
			return "Already Checked";
		} else {
			return "Available";
		}
	}

	public void setRatings(int ratings) throws Exception {
		this.setRatings((double) ratings);
	}

	public void setRatings(double ratings) throws Exception {
		if (ratings > 5 && ratings < 1)
			throw new Exception("Ratings must be in between 1 and 5");

		noOfRatings++;
		userRatings += ratings;
	}

	public double getAverageRating() {
		return (userRatings / noOfRatings);
	}

}

class VideoStore1 {

	private int count = 10;
	private Video1 videos[] = new Video1[count];
	private int addIndex = 0;

	public VideoStore1() {
		for (int i = 0; i < count; i++)
			videos[i] = null;
	}

	public void addVideo(Video1 video) throws Exception {
		if (VideoStore1.getVideoIndexByTitle(this, video.getTitle()) < 0) {
			if (this.addIndex < this.count - 1) {
				videos[this.addIndex++] = video;
			} else {
				throw new Exception("Maximum Adding limit reached!");
			}
		} else {
			throw new Exception("Video with the same name already exist!");
		}
	}

	public void addVideo(String title) throws Exception {
		if (VideoStore1.getVideoIndexByTitle(this, title) < 0) {
			videos[addIndex++] = new Video1(title);
		} else {
			throw new Exception("Video with the same name already exist!");
		}
	}

	public void checkOutVideo(String title) {
		int index = VideoStore1.getVideoIndexByTitle(this, title);
		if (index >= 0) {
			videos[index].beingChecked();
		}
	}

	public void returnVideo(String title) {
		int index = VideoStore1.getVideoIndexByTitle(this, title);
		if (index >= 0) {
			videos[index].beingReturned();
		}
	}

	public void recieveRating(String title, int rating) throws Exception {
		this.recieveRating(title, (double) rating);
	}

	public void recieveRating(String title, double rating) throws Exception {
		int index = VideoStore1.getVideoIndexByTitle(this, title);
		if (index >= 0) {
			videos[index].setRatings(rating);
		}
	}

	public Video1[] getVideos() {
		return this.videos;
	}

	public Video1 getVideoByIndex(int Index) {
		if (this.videos[Index] != null) {
			if (!this.videos[Index].getTitle().trim().equals("")) {
				return this.videos[Index];
			}
		}
		return null;
	}

	public static int getVideoIndexByTitle(VideoStore1 videoStore, String title) {
		int foundIndex = -1, index = -1;
		boolean found = false;
		for (Video1 vid : videoStore.getVideos()) {
			index++;
			if (vid != null) {
				if (vid.getTitle().equalsIgnoreCase(title)) {
					found = true;
					foundIndex = index;
				}
			}
			if (found)
				break;
		}
		return foundIndex;
	}

	public void listInventory() {
		VideoStore1.printAppTitle();
		VideoStore1.printHeader();
		int index;
		for (int i = 0; i< this.addIndex; i++) {
			Video1 vid = this.videos[i];
			VideoStore1.printRow(vid.getSL(), vid.getShortTitle(),
					vid.getAverageRating(), vid.getStatus());
		}
	}

	private static void printAppTitle() {
		System.out
        .println("\n                               Video Inventory System                             \n");
	
		System.out
				.println("................................................................................");
		}

	private static void printHeader() {
		System.out.println(String.format("| %-10s |  %-28s | %-15s | %-15s |",
				"SL. No.", "Video Title", "Avg Ratings", "Availability"));
		for (int i = 0; i < 41; i++)
			System.out.print("- "); 
		System.out.println();
	}

	private static void printRow(int sL, String title, double avgRatings,
			String availabilityStatus) {
		String output = String.format("| %-10s |  %-28s | %-15s | %-15s |", sL
				+ "", title, String.format("%.2f",avgRatings), availabilityStatus);
		System.out.println(output);
	}
}
