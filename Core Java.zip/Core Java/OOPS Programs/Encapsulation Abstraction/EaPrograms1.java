import java.util.Scanner;


class Auther
{
	String name;
	private String mail;
	char gender;
	public String author;
	
	public Auther(String name, String mail, String author, char gender) {
	
		this.name = name;
		this.mail = mail;
		this.gender = gender;
	}
}

class Book1
	{
	
		private String b_name;
		private String auther;
		private double price;
		private int qtyInStock;
		private String name;
		
		Book1(String b_name,String auther)
		{
			this.b_name=b_name;
			this.auther=auther;
			
		}
		public String getB_Name() {
			return b_name;
		}
		public void setB_Name(double price) {
			this.b_name = b_name;
		}
		public String getAuth() {
			return getAuth();
		}
		public void setAuth(String name) {
			this.name = name;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public int getQtyInStock() {
			return qtyInStock;
		}
		public void setQtyInStock(int qtyInStock) {
			this.qtyInStock = qtyInStock;
		}
		
		
	}

	public class EaPrograms1 {
	   public static void main(String[] args) {
		   String auth,e; char g;
		   
		   Auther au=new Auther ("James Gosling","","e", 'M');
		   
		   Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the name of book :");
		String n=sc.next();
		System.out.println("Enter the book of prize :");
		double p=sc.nextDouble();
		System.out.println("Enter the Quantity in Stock :");
		int q=sc.nextInt();
		
		auth=au.name;
		e=au.email;
		g=au.gender;
		
		
		Book1 b=new Book1(n,auth);
		b.setPrice(p);
		b.setQtyInStock(q);
		 System.out.println("book name :"+b.getB_Name());
		 System.out.println("Book Prize :"+b.getPrice());
		 System.out.println("Book Prize :"+b.getAuth());
		 
		
	
	}


}
