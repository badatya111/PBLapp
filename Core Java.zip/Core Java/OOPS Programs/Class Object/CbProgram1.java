
class Oops {
	double width;
	double height;
	double depth;
	Oops(double w, double h, double d) {
		width = w;
		height = h;
		depth = d;
	}
	double volume() 
	{
		return width * height * depth;
	}
}
class CbProgram1
{
	public static void main(String[] args) {

		Oops op=new Oops(20,30,40);
		Oops op1=new Oops(5,6,7);
		Oops op2=new Oops(2,7,6);
		double add;
		add = op.volume();
		System.out.println("Volume is " + add);
		add = op1.volume();
		System.out.println("Volume is " + add);
		add = op2.volume();
		System.out.println("Volume is " + add);
	}
}

