import java.util.Scanner;
class Health
{
	String n;
	double x,y,res;
	void setDimen(double l,double m)
	{
		x=l;
		y=m;
	}
	void setName(String s)
	{
		n=s;
	}
	double bmi()
	{
		res=(x/(y*y))* 703;
		return res;
	}
}
public class Cbprogram3 {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		String name;
		double weight,height;
		System.out.println("Enter the name : ");
		name=sc.next();
		System.out.println("Enter Weight");
		weight=sc.nextDouble();
		System.out.println("Enter Height");
		height=sc.nextDouble();
		Health hl=new Health();
		hl.setName(name);
		hl.setDimen(weight, height);
		System.out.println("Your BMI is "+hl.bmi());
	}
}
