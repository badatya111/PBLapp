import java.util.Scanner;


public class StringBuffer6 {
	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter the String : ");
		String str1,str2,str3;
		str1=sc.next();
		str2=sc.next();
		int a1=str1.length();
		int a2=str2.length();
		while(a1==a2)
		{
			System.out.println("Enter the String with out uneqal length ");
			System.out.println("Enter Another string");
			str1=sc.next();
			str2=sc.next();
			a1=str1.length();
			a1=str2.length();
			
		}
		if(a1<a2)
		{
			str3=str1.concat(str2.concat(str2));
			System.out.println(str3);
		
		}
		else if(a2<a1)
		{
			str3=str2.concat(str2.concat(str2));
			
		}
			
			
			
		
	}

}
