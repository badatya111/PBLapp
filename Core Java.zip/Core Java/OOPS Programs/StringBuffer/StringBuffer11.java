import java.util.Scanner;


public class StringBuffer11 {
	
	public static void main(String[] args) {
		
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter String ");
			String str1=sc.next();
			
			System.out.println("Enter the second String :");
			String str2=sc.next();
			int n=str1.length();
			for(int i=0;i<n;i++)
			{
				System.out.println(str1.charAt(i));
				System.out.println(str2.charAt(i));
				
			}
		}
	}

		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter String ");

		String str1=sc.next();
	
		String str2=sc.next();
		String str3="";
		
		StringBuffer stb1=new StringBuffer(str1);
		StringBuffer stb2=new StringBuffer(str2);
		StringBuffer stb3=new StringBuffer();
		
		
		int a=stb1.length();
		int b=stb2.length();
		
		int a1=0,b1=0,c1=0;
		if(a==b)
		{
			c1=a;
			c1=a+b;
			
		}
		else if(a>b)
		{
			a1=a-b;
			c1=b;
			str3=str1.substring(a-a1);
		}
		else if(a<b)
		{
			a1=a-b;
			c1=a;
			str3=str2.substring(b-a);
		}
		for(int i=0;i<a1;i++)
		{
			stb3.append(stb1.charAt(i));
			stb3.append(stb2.charAt(i));
		}
		if(a>b)
		{
			stb3.insert(c1, a1);
			
		}
		else if(a<b)
		{
			stb3.insert(c1+1, a1);
		}
		System.out.println("The New String is :"+stb3);
	
		
		
		
	}

}
*/