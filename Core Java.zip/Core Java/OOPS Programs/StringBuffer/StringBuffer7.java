import java.util.Scanner;


public class StringBuffer7 {

	public static void main(String[] args){

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter String ");

		String str=sc.next();
		int l=str.length();

		String str1 = null,ch1,ch2;
		ch1=Character.toString(str.charAt(0));
		ch2=Character.toString(str.charAt(l-1));
		System.out.println("Enter a String ");

		String str2;
		str2="X";

		if(ch1.equalsIgnoreCase(str2) && ch2.equalsIgnoreCase(str2))
		{
			str1=str.substring(1,(l-1));
			System.out.println("Enter the String :"+str1);

		}
		else if(ch1.equalsIgnoreCase(str2))
		{
			str=str.substring(1,l);
			System.out.println("The String is :"+str1);

		}
		else if(ch2.equalsIgnoreCase(str2))
		{
			str=str.substring(0,(l-1));
			System.out.println("String is :"+ str1);
		}
	}
}
