import java.util.Scanner;


public class StringBuffera8 {
	
	public static void main(String[] args) {
		

		Scanner sc=new Scanner(System.in);
		System.out.println("String name :");
		String str1,str2;
		String str3;
		str1=sc.next();
		
		str3=sc.next();
		System.out.println("Enter String :");
		
		int a=sc.nextInt();
		str2=str1;
		for(int i=1;i<a;i++)
		{
			str2=str2.concat(str3).concat(str1);
			
		}
		System.out.println("New String :"+str2);
		
	}

}
