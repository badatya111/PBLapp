import java.util.Scanner;


public class StringBuffer3 {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String :");
		
		String str1,str2,str3;
		str1=sc.next();
		int i=str1.length();
		if(i<2)
		{
			System.out.println("The String :"+str1);
			
		}else
		{
			str2=str1.substring(0,2);
			str3=str2;
			for(int j=0;j<(i-1);j++)
			{
				str3=str3.concat(str2);
				
			}
			System.out.println("The String is "+str3);
			
		}
		
		
	}

}
