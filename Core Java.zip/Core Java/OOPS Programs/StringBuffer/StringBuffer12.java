import java.util.Scanner;


public class StringBuffer12 {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		String str1=sc.next();
		String str2,str3;
		
		int l=str1.length();
		int a=sc.nextInt();
		
		if(a>0 && a<l)
		{
			int x=l-1;
			str1=str1.substring(x,l);
			str2=str1;
			for(int i = 0;i<x-1;i++)
			{
				str2=str2.concat(str1);
				
				
			}
		
		}
		else
		{
			System.out.println("Enter a value in validate :");
		}
		
		
	}

}
