
public class StringBuffer5 {

	public static void main(String[] args) {

		String text = "Wipro";
		String str = text.substring(1); 
		String str2= text.substring(1, text.length() - 1); 

		System.out.println("input string: " + text);

		System.out.println("without first and Last character: " +str2);
		System.out.println();

	}

}
