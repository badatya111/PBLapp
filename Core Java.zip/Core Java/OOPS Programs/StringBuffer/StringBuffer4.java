import java.util.Scanner;


public class StringBuffer4 {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		int n=str.length();
		
		if(n%2==0){
			String str2=str.substring(0,n/2);
			System.out.println("Enter name"+str2);
		
		
		}
		else
		{
			System.out.println("Empty");
		}
		
	}

}
