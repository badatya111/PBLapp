
public class StringBuffer2 {
	public static void main(String[] args) {
		
		String str1="Mark";
		String str2="Kate";
	
		String s="Kate".substring(1);
		String str=str1.concat(s);
		System.out.println("Enter "+str);
		String s1=str.toLowerCase();
		System.out.println("after");
	
	}

}
