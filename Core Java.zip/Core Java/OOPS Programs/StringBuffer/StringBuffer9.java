import java.util.Scanner;


public class StringBuffer9 {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		StringBuffer stb;
		System.out.println("Enter The String :");
		String str1=sc.next();
		
		int i=str1.length();
		int j=str1.indexOf('*');
		int k=str1.indexOf('*',j+1);
		int l=-1;
		for(int t=0;t<i-1;t++)
		{
			l=k;
			k=str1.indexOf('*',k+1);
			if(k==-1)
			{
				break;
				
			}
			
		}
		if(i==-1 && l==-1)
		{
			System.out.println(" New String "+str1);
		}
		else if(l==-1)
		{
			stb=new StringBuffer(str1);
			stb.delete(i-1, i+2);
			System.out.println("new String is "+stb);
			
		}
		else
		{
			stb=new StringBuffer(str1);
			stb.delete(i-1, l+2);
			System.out.println("new String is"+stb);
		}
	}

}
