
class Calculator 
{
      public static int powerInt(int num1,int num2)
	{
		int result=1;

		for(int i=1;i<num1;i++)
		{
			result *=num2;
		}
		System.out.println(result);

		return result;
}
	public static int  powerDouble(double num1,int num2)
	{
		int result=1;

		for(int i=1;i<num1;i++)
		{
			result *=num2;
		}
		System.out.println(result);

		return result;
	}
}
public class OopsProgram2
{
	public static void main(String[] args) {
		Calculator cl=new Calculator();
		cl.powerInt(6,3);
		Calculator cl1=new Calculator();
		cl.powerDouble(8,6);
	}
}


