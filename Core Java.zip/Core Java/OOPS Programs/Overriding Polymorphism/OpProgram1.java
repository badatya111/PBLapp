class Fruit
{
	String test,size;
	Fruit()
	{
	      test="Good";
	      size="larg";
		
	}
	
	void eat()
	{
		System.out.println("The frute Name");
	}
	
}
class Apple extends Fruit
{
	void eat()
	{
		System.out.println("Apple test :");
	}
	class Orange extends Apple
	{
		void eat()
		{
			System.out.println("Orage Test");
		}
	}
}
public class OpProgram1 {
	public static void main(String[] args) {
		
		Fruit ft=new Fruit();
		ft.eat();
		
	}

}
