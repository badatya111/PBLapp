class Animal{
}
	class Dog extends Animal
	{
		public Dog()
		{
			System.out.println("A new dog has been created!");
		}
		void eats()
		{
			System.out.println("A Dog eat");
		}
		void sleep()
		{
			System.out.println("A Dog sleeps");

		}
	}
	class Bird extends Dog {

		public Bird() {
			System.out.println("A new bird has been created");

		}
		public void sleep() {
			System.out.println("A bird sleeps");
		}
		public void eats() {
			System.out.println("A bird eats");
		}


		void fly()
		{
			System.out.println("");
		}

	}

public class InheritancePro1 {


	public static void main(String[] args) {

		Animal an=new Animal();
		Dog d=new Dog();
		Bird b=new Bird();

		b.eats();
		b.sleep();
		b.fly();
		
		d.eats();
		d.sleep();

	}
}



