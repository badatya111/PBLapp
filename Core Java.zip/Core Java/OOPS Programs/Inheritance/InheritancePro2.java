class Person
{
	String name;
	Person()
	{
		name="kumar";
	}
	Person(String name)
	{
		this.name=name;
	}
}
class Employee extends Person
{
	double salary;
	int year;
	String insurance;
	
	Employee()
	{
		salary=1500;
		year=2017;
		insurance="Lifeinsurance123";
	}
	public Employee(double sal,int year,String insurance)
	{
		this.name=name;
		this.salary=salary;
		this.year=year;
		this.insurance=insurance;	
	}	
}
public class InheritancePro2 {
		public static void main(String[] args) {
		Person p=new Person();
		Employee emp=new Employee();
		System.out.println("Name :"+p.name);
		System.out.println("Salary :"+emp.salary);
		System.out.println("Year :"+emp.year);
		System.out.println("Insurance :"+emp.insurance);
		
		Person p1=new Person();
		System.out.println("Namne: "+p1.name);
		Employee emp1=new Employee();
		
		System.out.println("Salary :"+emp1.salary);
		
		System.out.println("Year :"+emp1.year);
		System.out.println("Insurance :"+emp1.insurance);
	}	
}
