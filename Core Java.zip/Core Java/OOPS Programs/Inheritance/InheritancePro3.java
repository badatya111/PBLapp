import java.util.Scanner;


class Person1
{
	String name;
	int age;
	Person1(String name,int age)
	{
		this.name=name;
		this.age=age;	
	}

}
	class Student extends Person1
	
	{
		Student(String name,int age)
		{
			super(name,age);
		}
	}
class Teacher extends Person1
{
	double salary;
	String Subject;
	
	Teacher(String name,int age,double salary,String Subject)
	{
	super(name,age);
		this.salary=salary;
		this.Subject=Subject;
	}
	void display()
	{
		System.out.println("Name :"+name);
		System.out.println("Age :"+age);
		System.out.println("Salary :"+salary);
		System.out.println("Subject  :"+Subject);
	}
}
class ColllegeStudent extends Student
{
	
	int year;
	String major;
	
	ColllegeStudent(int year,int age,String name,String major)
	{
		super(name,age);
		this.year=year;
		this.major=major;
		
		
	}
	void display()
	{
		System.out.println("Name :"+name);
		System.out.println("Age :"+age);
		System.out.println("Year :"+year);
		System.out.println("Major :"+name);
	}

}
public class InheritancePro3 {
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		int age,year;
		double salary;
		
		String TeacherName,Student,sub,maj;
		
		System.out.println("Enter your choice (1& 2): ");
		System.out.println("1 teacher");
		System.out.println("2 Student");
		
		
		 int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			System.out.println("Enter Your Name :");
			TeacherName=sc.next();
			System.out.println("Enter Your Age");
			age=sc.nextInt();
			System.out.println("Enter Your Salary");
			salary=sc.nextDouble();
			System.out.println("Enter Your Subject");
			sub=sc.next();
			Teacher te=new Teacher(TeacherName, age, salary, sub);
			te.display();
			break;
		case 2:
			System.out.println("Enter Your Name :");
			Student=sc.next();
			System.out.println("Enter Your Age");
			age=sc.nextInt();
			System.out.println("Enter Your year");
			year=sc.nextInt();
			System.out.println("Enter Your major");
			maj=sc.next();
			break;
			default:
				System.out.println("Enter Validate input !!");
				break;
		
			



	}

}
