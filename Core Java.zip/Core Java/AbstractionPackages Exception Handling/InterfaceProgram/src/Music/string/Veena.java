package Music.string;

import Music.*;
public class Veena implements Playable {
	public void play()
	{
		System.out.println("veena is getting played live");
	}

	
}
