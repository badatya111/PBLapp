package Music.wind;
import Music.*;

public class Saxophone implements Playable {
	public void play()
	{
		System.out.println("Saxophone is getting played live");
	}

	
}
