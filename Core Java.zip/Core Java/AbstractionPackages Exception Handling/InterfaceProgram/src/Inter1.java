interface LibraryUser
{
	String name();
	void registerAccount();
	void requestBook();
}
class KidUser implements LibraryUser
{int age;
String bookType;

	int age(int age)
	{this.age=age;
		return age;}
	
	String bookType(String bookType)
	{this.bookType=bookType;
		return bookType;}
	
	public void registerAccount()
	{
		if(age<12)
		{System.out.println("You have successfully registered under a Kids Account");}
	
		if(age>12)
		
		{System.out.println("Sorry, Age must be less than 12 to register as a kid");}}
	public void requestBook(){

	    if(bookType.equals("kids"))
	    {System.out.println("Book Issued successfully, please return the book within 10 days");}
	    else
	    {System.out.println("Oops, you are allowed to take only kids books");}
	}

	
	public String name() {
		
		return null;
	}
}
 class AdultUser implements LibraryUser{
	int age;
	String bookType;

		int age(int age)
		{this.age=age;
			return age;}
		
		String bookType(String bookType)
		{this.bookType=bookType;
			return bookType;}
		public void registerAccount()
		{
			if(age>12)
			{System.out.println("You have successfully registered under an Adult Account");}
		
			if(age<12)
			
			{System.out.println("Sorry, Age must be less than 12 to register as a kid");}
			}
	public void requestBook()
	{     if(bookType.equalsIgnoreCase("Fiction"))
	     System.out.println("Book Issued successfully, please return the book within 7 days");
	      else
		System.out.println("Oops, you are allowed to take only adult Fiction books");}

	
	public String name() {
	
		return null;
	}
	
	
}
	

	
	
	
	
	
	
	
	
	
