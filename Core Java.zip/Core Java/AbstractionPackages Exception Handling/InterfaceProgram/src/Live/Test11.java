package Live;

import Music.*;
import Music.string.*;
import Music.wind.*;
public class Test11{
	public static void main(String[] args)
	{
		Veena a = new Veena();
		a.play();
		Saxophone b= new Saxophone();
		b.play();
		
		
	}
}