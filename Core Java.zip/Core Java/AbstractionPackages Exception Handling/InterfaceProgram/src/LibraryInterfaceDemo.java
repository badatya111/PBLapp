import java.util.Scanner;


public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("press 1 for kids user and 2 for adult user");
		int u=sc.nextInt();
		switch(u){
		case 1 :
		
		System.out.println("enter the age");
		int s=sc.nextInt();
		int s2=sc.nextInt();
		KidUser k= new KidUser();
		k.age(s);
		k.registerAccount();
		k.age(s2);
		k.registerAccount();
		String b=sc.next();
		k.bookType(b);
		k.requestBook();
		String b2=sc.next();
		k.bookType(b2);
		k.requestBook();
		break;
		case 2 :
			System.out.println("enter the age");
			int x=sc.nextInt();
			int x1=sc.nextInt();
			AdultUser p= new AdultUser();
			p.age(x);
			p.registerAccount();
			p.age(x1);
			p.registerAccount();
			String r=sc.next();
			p.bookType(r);
			p.requestBook();
			String r1=sc.next();
			p.bookType(r1);
			p.requestBook();
			break;
		default :
			System.out.println("invalid input");
			
			
		
		

	}
	}
}
