package com.wipro.automobile.ship;

public class RailCoach {
	double heigt=2;
	double weight=3;
	double length=4;

	

}
