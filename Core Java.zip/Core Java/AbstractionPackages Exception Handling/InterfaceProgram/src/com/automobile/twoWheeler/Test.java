package com.automobile.twoWheeler;

import java.util.Scanner;


public class Test {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter choice 1 for hero and 2 for Honda");
		int i=sc.nextInt();
		switch(i){
		case 1 : 
		Hero y= new Hero();
		System.out.println("model name "+y.getModelName());
        System.out.println("Ragistration no. "+y.getRegistrationNumber());
        System.out.println("owner name  "+y.getOwnerName());
        System.out.println("Current Speed "+y.getSpeed()+"km");
        System.out.println("enter radio option");
        int k=sc.nextInt();
        y.radio(k);
        break;
		case 2 :
			Honda z=new Honda();
			System.out.println("model name "+z.getModelName());
	        System.out.println("Ragistration no. "+z.getRegistrationNumber());
	        System.out.println("owner name  "+z.getOwnerName());
	        System.out.println("Current Speed "+z.getSpeed()+"km");
	        System.out.println("cd player option");
	        int f=sc.nextInt();
	        z.cdPlayer(f);
	        break;
	     default :
	    	 System.out.println("invalid input");
	    	 
			
		}
	}
}
