package com.automobile.twoWheeler;
import com.automobile.*;

public class Honda extends Vehicle {

	public String getModelName()
	{
		String s= "hondact";
		return s;
	}
	public String getRegistrationNumber()
	{String a="ra1234";
	return a;
	}
	public String getOwnerName()
	{
		String b="shivam";
		return b;
	}
	public int getSpeed()
	{ 
		int c=20;
		return c;
	}
	public void cdPlayer(int x)
	{switch(x)
		{
		case 1 :
		System.out.println("cdplayer on");
		break;
		case 2 :
		System.out.println("cdplayer off");
		break;
		default :
		System.out.println("press the right button");}	
	
	
	}
}