package com.automobile.fourWheeler;

import com.automobile.*;

public class Logan extends Vehicle 
{
	public String getModelName()
	{
		String s= "LoganWh";
		return s;
	}
	public String getRegistrationNumber()
	{String a="ra1234";
	return a;
	}
	public String getOwnerName()
	{
		String b="rahul";
		return b;
	}
	public int speed()
	{
		return 20;
	}
	public int gps(int x)
	{
		if(x==1)
			return 1;
		else if(x==2)
			return 2;
		else
			return -1;
	}
		
}
	


