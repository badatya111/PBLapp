package com.automobile.fourWheeler;

public class Exception1 {

	public static void main(String[] args) {
	
		try {
			int a=Integer.parseInt(args[0]);
			int b=a*a;
			System.out.println("square of number "+ b);
		}
		catch(NumberFormatException w){
			System.out.println("enter the integer no");
			
		}
		
		
        
	}

}
