package com.automobile.fourWheeler;
import java.util.Scanner;

import com.automobile.Vehicle;


public class Test1 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter choice 1 for hero and 2 for Honda");
		int i=sc.nextInt();
		switch(i){
		case 1 : 
		Logan l= new Logan();
		System.out.println("model name "+l.getModelName());
		 System.out.println("Ragistration no. "+l.getRegistrationNumber());
	        System.out.println("owner name  "+l.getOwnerName());
	        System.out.println("Current Speed "+l.speed()+"km");
	        System.out.println("enter gps option ");
	        int k=sc.nextInt();
	        int h=l.gps(k);
	        
	        switch(h){
	        case 1:
	        	System.out.println("gps is on");
	        	break;
	        case 2 :
	        	System.out.println("gps is off");
	        	break;
	        default :
	        	System.out.println("invalid option");
	        }
	        
	        break;
		case 2 :
			Ford f=new Ford();
			System.out.println("model name "+f.getModelName());
			 System.out.println("Ragistration no. "+f.getRegistrationNumber());
		        System.out.println("owner name  "+f.getOwnerName());
		        System.out.println("Current Speed "+f.speed()+"km");
		        System.out.println("enter AC option ");
		        int g=sc.nextInt();
		        int o=f.tempControl(g);
		        switch(o){
		        case 1 :
		        	System.out.println("AC is on");
		        	break;
		        case 2 :
		        	System.out.println("Ac ic off");
		        	break;
		        default :
		        	System.out.println("invalid option");}
		         break;
		        default :
		        	System.out.println("invalid input");
		        	
		        }
			
		
		
	}

}

	
/*Scanner sc= new Scanner(System.in);
		System.out.println("enter choice 1 for hero and 2 for Honda");
		int i=sc.nextInt();
		switch(i){
		case 1 : 
		Hero y= new Hero();
		System.out.println("model name "+y.getModelName());
        System.out.println("Ragistration no. "+y.getRegistrationNumber());
        System.out.println("owner name  "+y.getOwnerName());
        System.out.println("Current Speed "+y.getSpeed()+"km");
        System.out.println("enter radio option");
        int k=sc.nextInt();
        y.radio(k);
        break;
		case 2 :
			Honda z=new Honda();
			System.out.println("model name "+z.getModelName());
	        System.out.println("Ragistration no. "+z.getRegistrationNumber());
	        System.out.println("owner name  "+z.getOwnerName());
	        System.out.println("Current Speed "+z.getSpeed()+"km");
	        System.out.println("cd player option");
	        int f=sc.nextInt();
	        z.cdPlayer(f);
	        break;
	     default :
	    	 System.out.println("invalid input");
	    	 
			
		}
	}
}
*/