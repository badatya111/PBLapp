package com.automobile.fourWheeler;
import com.automobile.*;

public class Ford extends Vehicle{

	public String getModelName()
	{
		String s= "Ford 200";
		return s;
	}
	public String getRegistrationNumber()
	{String a="ra1234";
	return a;
	}
	public String getOwnerName()
	{
		String b="rahul";
		return b;
	}
	public int speed()
	{
		return 20;
	}
	public int tempControl(int x)
	{
		if(x==1)
			return 1;
		else if(x==2)
			return 2;
		else 
			return -1;
	}}