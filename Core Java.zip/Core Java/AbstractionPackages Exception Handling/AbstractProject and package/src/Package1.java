import com.core.*;
public class Package1 {
	
	public static void main(String[] args) {
		System.out.println("hello");
		
		
		
	}

}
