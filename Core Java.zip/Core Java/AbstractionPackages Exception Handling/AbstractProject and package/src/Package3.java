
import com.automobile.*;
import com.automobile.TwoWheeler.*;
import Vehicle.Vehicle;

import com.automobile.*;

import java.util.Scanner;


public class Package3 {
	public static void main(String[] args) {
		
		Vehicle v=new Hero();
		Vehicle v1=new Honda();
		
		System.out.println("----------------------------------------------------------------");
		System.out.println("		Details of HERO Configuration");
		System.out.println("----------------------------------------------------------------");
		System.out.println("		Hero ModelName : "+v.getModelName());
		System.out.println("		Hero OwnerName	: "+v.getOwnerName());
		System.out.println("		Hero RegistrationNumber : "+v.getRegistrationNumber());
        System.out.println("		Hero cdplayer :");
		System.out.println("----------------------------------------------------------------");
		System.out.println("		Details of HONDA Configuration");
		System.out.println("----------------------------------------------------------------");
		System.out.println("		Honda ModelName	: "+v1.getModelName());
		System.out.println("		Honda OwnerName	: "+v1.getOwnerName());
		System.out.println("		Honda RegistrationNumber  : "+v1.getRegistrationNumber());
		 System.out.println("		Honda cdplayer :");
		System.out.println("----------------------------------------------------------------");
		
		
	
	}

}
