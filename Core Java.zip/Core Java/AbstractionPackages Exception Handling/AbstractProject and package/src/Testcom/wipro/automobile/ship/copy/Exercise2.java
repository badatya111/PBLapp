package Testcom.wipro.automobile.ship.copy;
import Testcom.wipro.automobile.*;
import Testcom.wipro.automobile.ship.*;
import com.wipro.automobile.ship.*;
public abstract class Exercise2 {
	public static void main(String[] args) {
		
	

	Compartment c=new Compartment();
	int a=c.height;
	int a1=c.breadth;
	int a2=c.width;
	
	
	
	}
	
}
