package abc;
//import com.core.test1.*;
import com.core.test1.*;
import com.core.test1.Package;
public class Package1 {
	
	public static void main(String[] args) {
		System.out.println("hello");
		
		Package p=new Package();
		p.Package();
		
	}

}
