import java.util.Scanner;

import abc.Vehicle;

import com.automobile.FourWheeler.Ford;
import com.automobile.FourWheeler.Logan;


public class Program4 {
	public static void main(String[] args) {
		
		
		Vehicle v;Logan l;
		v=new Logan();
		l=new Logan();
		
		Vehicle v1;Ford l1;
		//v1=new Ford();
		//l1=new Ford();
		System.out.println(""+v.getModelName());
		System.out.println(""+v.getOwnerName());
		System.out.println(""+v.getRegistrationNumber());
		System.out.println(""+l.speed());
		
		Scanner sc=new Scanner(System.in);
		int i;
		System.out.println("Enter a Number Between 1 to 3");
		i=l.gps(sc.nextInt());
		switch(i)
		{
		case 1:
			System.out.println("GPS Activated :");
			break;
		case 2:
			System.out.println("GPS DeActivate :");
			break;
		case 3:
			System.out.println("GPS is Off");
			
		
		}
		
		
		
		
		
		
		
		
	}
	

}
