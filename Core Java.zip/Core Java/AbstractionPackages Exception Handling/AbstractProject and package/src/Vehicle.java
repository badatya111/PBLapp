
import com.automobile.*;
import com.automobile.TwoWheeler.*;
import com.automobile.FourWheeler.*;

public abstract class Vehicle {

	public abstract String getModelName();
	
	public abstract String getRegistrationNumber();
	
	public abstract String getOwnerName();

}
