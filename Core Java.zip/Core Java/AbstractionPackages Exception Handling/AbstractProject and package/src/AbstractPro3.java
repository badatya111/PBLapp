import java.util.Scanner;

abstract class Instrument
{
	abstract void  play();
}

class Piano extends Instrument
{
	void play()
	{
		System.out.println("Piano is playing  tan tan tan tan ");
	}
}
class Flute extends Instrument
{
	void play()
	{
		System.out.println("Flute is playing  toot toot toot toot ");
	}
}
class Guitar extends Instrument
{
	void play()
	{
		System.out.println("Guitar is playing  tin  tin  tin ");
	}
}

public class AbstractPro3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Compertment bitween 1 to 3 :");
		Instrument i;
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			i=new Piano();
			i.play();
			break;
		case 2:
			i=new Flute();
			i.play();
			break;

		case 4:
			i=new Guitar();
			i.play();
			break;
		default:
			System.out.println("empty");
			break;

		}

	}

}
