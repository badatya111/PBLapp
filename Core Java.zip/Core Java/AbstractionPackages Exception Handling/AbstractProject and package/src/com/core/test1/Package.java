package com.core.test1;

public class Package {

		
		int var1=10;
		public int var2=20;
		protected int var3=30;
		private int var4=40;
		
		public Package() {
			// TODO Auto-generated constructor stub
			System.out.println("Smruti");
		}

		public void Package() {
			// TODO Auto-generated method stub
			
		}
		
	}
