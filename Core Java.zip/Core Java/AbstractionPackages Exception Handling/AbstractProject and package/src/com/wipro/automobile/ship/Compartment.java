package com.wipro.automobile.ship;

public  class Compartment {

	public int	height=12, width=10, breadth=5; 


	public Compartment()
	{
		System.out.println("Height :"+height);
		System.out.println("Width :"+width);
		System.out.println("Breadth :"+breadth);
	}

}
