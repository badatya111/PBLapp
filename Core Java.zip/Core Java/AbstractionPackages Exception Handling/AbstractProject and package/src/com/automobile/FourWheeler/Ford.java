package com.automobile.FourWheeler;
import abc.Vehicle;


public abstract class Ford extends Vehicle {

	public  String getModelName() {
		return "Grand";
	}
	
	public  String getRegistrationNumber() {
		return "125MZ";
	}
	
	public  String getOwnerName() {
		return "SAmeer";
	}

	public int speed()
	{
		return 60;
	}
	public int gps(int y)
	{
		if(y==1)
		{
			return 1;
		}
		else if(y==2)
		{
			return 2;
		}
		else  {
			return -1;
		}
	}
}