package com.automobile.FourWheeler;

import abc.Vehicle;
public class Logan extends Vehicle {

	public  String getModelName() {
		return "Lenova";
	}
	
	public  String getRegistrationNumber() {
		return "125KJ";
	}
	
	public  String getOwnerName() {
		return "Kumar";
	}

	public int speed()
	{
		return 60;
	}
	public int gps(int x)
	{
		if(x==1)
		{
			return 1;
		}
		else if(x==2)
		{
			return 2;
		}
		else  {
			return -1;
		}
	}
}
