package com.automobile.TwoWheeler;

import Vehicle.Vehicle;

import com.automobile.*;

public class Hero extends Vehicle{
	
	public  String getModelName()
	{
		return "Glamour";
		
	}
	public  String getRegistrationNumber()
	{
		return "HI-12345";
	}
	public  String getOwnerName()
	{
		return "Raghab";
	}
	
	public  int getSpeed()
	{
		return 70;
		
	}
	public void cdplayer() 
	{
		System.out.println(" Hero cdplayer");
	}
	

}
