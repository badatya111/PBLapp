package com.automobile.TwoWheeler;

import Vehicle.Vehicle;

import com.automobile.*;

public class Honda extends Vehicle {
	
		
		public  String getModelName()
		{
			return "Plzer";
			
		}
		public  String getRegistrationNumber()
		{
			return "HO-12345";
		}
		public  String getOwnerName()
		{
			return "Remesh";
		}
		
		public  int getSpeed()
		{
			return 65;
			
		}
		public void cdplayer() 
		{
			System.out.println("Honda cdplayer");
			
		}
		

	}
