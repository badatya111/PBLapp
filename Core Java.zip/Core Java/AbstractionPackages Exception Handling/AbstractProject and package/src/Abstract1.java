
abstract class GeneralBank
{
	abstract double getSavingInterestRate();
	abstract double getFixedInterestRate();
}

class ICICIBank extends GeneralBank
{
	public double getSavingInterestRate()
	{
		return 4;
		
	}
	public double getFixedInterestRate()
	{
		return 8.5;
		
	}
}

class KotMBank extends GeneralBank
{
	public double getSavingInterestRate()
	{
		return 6;
		
	}
	public double getFixedInterestRate()
	{
		return 9;
		
	}

}
public class Abstract1 {
	public static void main(String[] args) {

		
		GeneralBank gb1=new ICICIBank();
		GeneralBank db1=new KotMBank();
		ICICIBank ib=new ICICIBank();
		KotMBank kb=new KotMBank();
		
		
		System.out.println("ICICI - Savings"+gb1.getSavingInterestRate());
		System.out.println("ICICI Fixed"+gb1.getFixedInterestRate());
		System.out.println("----------------------------------------");
		
		System.out.println("ICICI - Savings"+ib.getSavingInterestRate());
		System.out.println("ICICI Fixed"+ib.getFixedInterestRate());
		
		System.out.println("----------------------------------------");
		System.out.println("KotMBank - Savings"+db1.getSavingInterestRate());
		System.out.println("KotMBank Fixed"+db1.getFixedInterestRate());
		
		System.out.println("----------------------------------------");
		
		System.out.println("KotMBank - Savings"+kb.getSavingInterestRate());
		System.out.println("KotMBank  Fixed"+kb.getFixedInterestRate());
		
		
		

	
	}


}
