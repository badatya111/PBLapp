import java.util.Scanner;



abstract class Compartment
{
	abstract void notice();

}
class FirstClass extends Compartment
{
	void notice()
	{
		System.out.println("FirstClass");

	}
}
class Ladies extends Compartment
{
	void notice()
	{
		System.out.println("Ladies");

	}

}
class General extends Compartment
{
	void notice()
	{
		System.out.println("General");

	}

}
class Luggage extends Compartment
{

	void notice()
	{
		System.out.println("Luggage");

	}
}
public class Abstract2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Compertment bitween 1 to 4 :");
		Compartment c;
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			c=new FirstClass();
			c.notice();
			break;
		case 2:
			c=new Ladies();
			c.notice();
			break;
		case 3:
			c=new General();
			c.notice();
			break;
		case 4:
			c=new Luggage();
			c.notice();
			break;
			default:
				System.out.println("empty");
				break;
		}
	}

}
