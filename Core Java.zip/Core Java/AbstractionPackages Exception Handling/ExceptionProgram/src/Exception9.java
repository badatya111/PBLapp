import java.util.Scanner;


public class Exception9 {
	
	public static void main(String[] args) {
		int a,b;
		double c;
		
		Scanner sc =new Scanner(System.in);
		
		try
		{
			System.out.println("Enter 2 disit Number :");
			a=sc.nextInt();
			b=sc.nextInt();
			c=a/b;
			System.out.println("Divison " +a+ " by " +b+ " = "+c);
			
		}catch(ArithmeticException e)
		{
			System.out.println("DivideByZeroException caught");
			
		}
		finally
		{
			System.out.println("Inside finally block");
		}
		
	}

}
