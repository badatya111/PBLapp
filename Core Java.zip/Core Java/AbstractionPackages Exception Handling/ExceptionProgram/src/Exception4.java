
public class Exception4 {
	public static void main(String[] args)throws ArithmeticException,NumberFormatException
	{
		int sum = 0;
	    int avg = 0;
	    
	try
	{
		int array[]=new int[100];
		
		for(int i=0;i<100;i++)
		{
			array[i]=Integer.parseInt(args[i]);
			sum=sum+i;
			
		}
		System.out.println("The Sum of Number"+sum);
		
		System.out.println("The Avrage "+avg);
		
	}catch(ArithmeticException e)
		{
		}
		catch(NumberFormatException e)
		{
			
		}
			
		}
	}


