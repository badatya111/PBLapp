import java.util.Scanner;


public class Exception3 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int a,b,array[];
		
		try
		{
			System.out.println("Enter the number of elements in the array");
			a=sc.nextInt();
			array=new int[a];
			System.out.println("Enter the elements in the array");
			for(int i=0;i<a;i++)
			{
				b=sc.nextInt();
				array[i]=b;
			}
				System.out.println("Enter the index of the array element you want to access");
				int index=sc.nextInt();
				System.out.println("The value of array at Index is "+array[index]);
				System.out.println("The array element successfully accessed");
			
		}catch(NumberFormatException e)
			{
				System.out.println(e);
			}catch(IndexOutOfBoundsException e1)
			{
				System.out.println(e1);
		}
	}

}
