import java.util.Scanner;


class RangeException extends Exception
{

public RangeException()
{
	System.out.println("User Defined Exception Thrown");
}
public String toString()
{
	return "Marks cannot be Negative or greater than 100";
}
}
public class Exception6
{
public static void main(String[] args) throws RangeException,NumberFormatException
{
	String a,b;
	int arr1[]=new int[3];
	int arr2[]=new int[3];
	int sum1=0,sum2=0;
	String arr[]={"Physics","Chemistry","Maths"};
	Scanner sc=new Scanner(System.in);
	try
	{
		System.out.println("Student 1 Details : ");
		System.out.println("Enter the Student Name :");
		a=sc.next();
		System.out.println("Enter the Marks of Physics,Chemistry and Maths : ");
		for(int i=0;i<3;i++)
		{
			arr1[i]=Integer.parseInt(sc.next());
			if(arr1[i]<0 || arr1[i]>100)
			{
				throw new RangeException();
				
			}
			else
			{
				sum1=sum1+arr1[i];
				System.out.println("Marks in "+arr[i]+"="+arr1[i]);
			}
		}
		System.out.println("\nStudent 2 Details : ");
		System.out.println("Enter the Student Name :");
		b=sc.next();
		System.out.println("Enter the Marks of Physics,Chemistry and Maths : ");
		for(int i=0;i<3;i++)
		{
			arr2[i]=Integer.parseInt(sc.next());
			if(arr2[i]<0 || arr2[i]>100)
			{
				throw new RangeException();
			}
			else
			{
				sum2=sum2+arr2[i];
				System.out.println("Marks in "+arr[i]+"="+arr2[i]);
			}
		}
		System.out.println("\nThe Average Marks of "+a+"="+sum1/3);
		System.out.println("The Average Marks of "+b+"="+sum2/3);
	}
	catch(NumberFormatException e)
	{
		System.out.println(e);
	}
	catch(RangeException e)
	{
		System.out.println(e);
	}
}
}
