import java.util.Scanner;


class InvalidCountryException extends Exception
{
	public InvalidCountryException()
	{}
	public InvalidCountryException(String x)
	{
		System.out.println("User Country is "+x);
	}
	public String toString()
	{
		return "User Outside India cannot be registered";
	}
}
public class Exception7 
{
	static void registerUser(String username,String userCountry)
	{
		try
		{
			if(userCountry.equalsIgnoreCase("India"))
			{
				System.out.println("Name\tCountry\tExpected Output");
				System.out.println(username+"\t"+userCountry+"\tUser registeration done successfully");
			}
			else
			{
				throw new InvalidCountryException(userCountry);
			}
		}
		catch(InvalidCountryException e)
		{
			System.out.println("Name\tCountry\t\tExpected Output");
			System.out.println(username+"\t"+userCountry+"\t"+e);
		}
	}
	public static void main(String[] args) throws InvalidCountryException
	{
		String b,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the UserName & Country :");
		b=sc.next();c=sc.next();
		registerUser(b,c);
	}
}
