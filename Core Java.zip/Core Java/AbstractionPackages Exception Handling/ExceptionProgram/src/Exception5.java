
public class Exception5 {
	public static void main(String[] args)throws ArithmeticException
	{
		try{
		int a=12,b=0;
		
			int c1=a/b;
			System.out.println("division "+c1);
		}catch(Exception e)
		{
			System.out.println(e);
			}
	}
	}


