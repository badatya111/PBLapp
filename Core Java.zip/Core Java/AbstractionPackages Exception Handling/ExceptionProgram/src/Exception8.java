class AgeException extends Exception
{
	public AgeException()
	{
		
	}
	public AgeException(String a,int b)
	{
		System.out.println("Age of "+a+" is "+b);
	}
	public String toString()
	{
		return "Age cannot be less than 18 or greater than 59";
	}
}
public class Exception8 
{
	public static void main(String[] args) 
	{
		String name;int age;
		name=args[0];
		age=Integer.parseInt(args[1]);
		try
		{
			if(age<18 || age>=60)
			{
				throw new AgeException(name,age);
			}
			else
			{
				System.out.println("Name = "+name);
				System.out.println("Age = "+age);
			}
		}
		catch(AgeException e)
		{
			System.out.println(e);
		}
	}
}
