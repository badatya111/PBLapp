import java.util.Scanner;


public class Prog3 {

	public static void main(String[] args) {

		/*int a=Integer.parseInt(args[0]);*/

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter a Number");

		int a=sc.nextInt();

		if (a > 0)
		{
			System.out.println("Number is positive");
		}
		else 
		{
			System.out.println("Number is negative"); 
		}

	}

}
