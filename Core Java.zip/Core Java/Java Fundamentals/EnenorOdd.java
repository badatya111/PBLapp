import java.util.Scanner;


public class EnenorOdd {
	public static void main(String[] args) {
		int a;
		System.out.println("Enter the Number");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		
	
			if ( a % 2 == 0 ){
				System.out.println("This is Even Number");
			}
			else{
				System.out.println("this is Odd Number");
			}
		
	}

}
