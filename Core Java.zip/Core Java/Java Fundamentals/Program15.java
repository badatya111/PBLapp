import java.util.Scanner;


public class Program15 {
	
	public static void main(String[] args) {

        int sum = 0;
        for(int i=1 ; i<=2 ; i++){
            Scanner s = new Scanner( System.in);
            System.out.println("Enter number" + " " + i);
            int b = s.nextInt();
            sum = sum + b;
        }
        System.out.println("The result is :" + sum ); 
}
}