
public class Array4 {

	public static void main(String[] args) {
		int []array1={45,65,24,34,68,75,28,89};
		
		for(int j=0;j<array1.length;j++)
		
		{
	System.out.println((char)array1[j]+" ");		
		}
	}
	
}
