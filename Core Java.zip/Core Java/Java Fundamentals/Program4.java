import java.util.Scanner;

public class Program4 {
	

		public static void main(String[] args)
	    {
	    	char ch1='A';
	    	char ch2='B';
	    	
	    	if(ch1 > ch2)
	    	{
	    		System.out.println(ch2+ " , "+ch1);
	    	}
	    	else
	    	{
	    		System.out.println(ch1+ " , "+ch2);
	    	}
	    	
	    	
	    	
	    }
}

