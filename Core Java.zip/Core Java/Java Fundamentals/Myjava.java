
	public class Myjava {

		public static void main(String args[])
	{
		int a=10;
		int b=20;
		int c=a+b;
	System.out.println("The addition of the number are "+(a+b));}
}
