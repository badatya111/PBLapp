import java.util.Arrays;
import java.util.Scanner;


public class Array8 {
	public static void main(String[] args) {
		Scanner abc=new Scanner(System.in);
		int a[]= new int[5];
		System.out.println("Enter 5 numbers");
		for(int i=0;i<a.length;i++)
		{
		a[i]=abc.nextInt();
		}
		 Arrays.sort(a);
		int j=a.length;
		System.out.println("1st maximum number is"+a[j-1]);
		System.out.println("2nd maximum number is"+a[j-2]);
		System.out.println("1st minimum number is"+a[0]);
		System.out.println("1st maximum number is"+a[1]);
		}
		}