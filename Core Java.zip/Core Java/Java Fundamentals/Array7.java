
public class Array7 {
	
	public static void main(String[] args) {
		
		int array[]={10,15,30,16,15,10,15,60,70};
		int size= array.length;
		
		for(int i=0;i< size;i++)
		{
			for(int j=0;j< size;j++)
			{
				if(array[i] == array[j])
				{
					while (j < (size) - 1) 
                    {
                        array[j] = array[j + 1];
                        j++;
                    }   
                    size--;
				}
			}
		}
		 System.out.println("Size After deletion: " + size);
		 
         for (int k = 0; k < size; k++) 
         {
             System.out.println(array[k]);
	}
  }

}
