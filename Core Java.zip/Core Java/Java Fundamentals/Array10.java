import java.util.Scanner;


public class Array10 {
	public static void main(String[] args) {
		
		Scanner abc=new Scanner(System.in);
		System.out.println("Enter the elements of the array");
		int l= abc.nextInt();
		int a[]=new int[1];
		System.out.println("Enter the elemnt");
		for(int i=0;i<l;i++)
		{
			a[i]=abc.nextInt();
	}
int max=0;
int num=0;
for(int k=0;k<1;k++)
{
	int c=0;
	for(int j=0;j<1;j++)
	{
		if(a[k]==a[j])
		{
			c++;
		}
		if(c>=max)
		{
			max=c;
			num=a[k];
			
		}
		}
	}
System.out.println("elements occuring highest number of times"+num);
}
}


