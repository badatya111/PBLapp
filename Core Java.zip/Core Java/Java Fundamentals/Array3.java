import java.util.Scanner;


public class Array3 {
	
	public static void main(String[] args) {
		Scanner abc=new Scanner(System.in);
		int a[]= new int[10];
		System.out.println("Enter 10 numbers");
		for(int i=0;i<a.length;i++)
		{
		a[i]=abc.nextInt();
		}
		System.out.println("Enter the search element");
		int search=abc.nextInt();
		int c=0;
		int index=0;
		for(int i=0;i<a.length;i++)
		{
		if(a[i]==search)
		{
		c=c+1;
		index=i;
		}
		}
		if(c==0)
		{
		System.out.println("-"+1);
		}
		else
		{
		System.out.println(""+index);
		}
		}
		}