import java.util.Scanner;


public class Program8 {
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.print("Enter color code: ");
		char color=Character.toUpperCase(sc.next().charAt(0));
	
		switch(color)
		{
		case 'R':
			System.out.println("Rad");
			break;
		case 'B':
			System.out.println("Blue");
			break;
		case 'W':
		    System.out.println("wellow");
		break;
		
		case 'G':
		     System.out.println("Green");
		break;
		
		case 'S':
		     System.out.println("Sky");
		break;
		
		default:
			System.out.println("Invalid color.");
			break;

		}
	}

	}
