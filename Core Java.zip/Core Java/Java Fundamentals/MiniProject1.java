import java.util.Scanner;


public class MiniProject1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Employee id:");
		int n=sc.nextInt();
		
if(n==1001||n==1002||n==1003||n==1004||n==1005||n==1006||n==1007)
{
	switch(n)
	{
	case 1001:
		System.out.println("EmpNo  EmpName  Department  Designation  Salary" );
		System.out.println("1001    Ashish     R&D       Engineer    45000");
	   
	    break;
	case 1002:
		System.out.println("EmpNo  EmpName  Department  Designation  Salary" );
		System.out.println("1002   Shusma     PM         Consultant    65000");
	   
		
	    break;
	case 1003:
		System.out.println("EmpNo  EmpName  Department  Designation  Salary" );
		System.out.println("1003    Rahul     Acct       Clerk        29000");
	   
	
	    break;
	case 1004:
		System.out.println("EmpNo  EmpName  Department  Designation  Salary" );
		System.out.println("1004    Chahat   Front Desk  Receptionist  31000");
	  
	    break;
	case 1005:
		System.out.println("EmpNo  EmpName  Department  Designation  Salary" );
		System.out.println("1005    Ranjan    Engg       Manager     90000");
	   
		
	    break;
	case 1006:
		System.out.println("EmpNo  EmpName  Department  Designation  Salary" );
		System.out.println("1006    Suman   Manufacture  Engineer    47600");
	   
		
	    break;
	case 1007:
		System.out.println("EmpNo  EmpName  Department  Designation  Salary" );
		System.out.println("1007   Thanmay     PM       Consultant    43000");
	   
		
	    break;
	}
}
	else
	{
		System.out.println("There is no employee with given emp id");
	}
	}


	}

