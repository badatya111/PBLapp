import java.util.Scanner;


public class Program5 {
	public static void main(String[] args) {
		
	char ch;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Alphabit number");
		ch=(char) sc.nextInt();
		if (ch ==0 )
		{
			System.out.println("");
		}
		
		
	}

} 
