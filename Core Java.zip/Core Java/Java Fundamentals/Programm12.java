import java.util.Scanner;


public class Programm12 {
	
	public static void main(String[] args) {
		
		int temp;
		boolean prime=true;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the NUmber");
		int num= sc.nextInt();
		for(int i=2;i<=num/2;i++)
		{
			temp=num%i;
			if(temp ==0)
			{
				prime=false;
				break;
				
			}
		}
		if(prime)
		{
			System.out.println(num+ " is Prime");
		}
		else
		System.out.println(num+" is Not a prime");
		
		
	}

}
