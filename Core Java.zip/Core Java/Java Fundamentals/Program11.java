
public class Program11 {
	public static void main(String[] args) {
		
	  int a = 57;
      
      System.out.println("Printing Even numbers between 32 and " + a);
     
      for(int i=32; i <= a; i++){
             
              if( i % 2 == 0){
                      System.out.print(i + " ");
              }
      }
	}
}
