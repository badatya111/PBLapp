
public class Program7 {
public static void main(String[] args) {
		
		int n= Integer.parseInt(args[1]);
		if(args[0].equalsIgnoreCase("Male"))
		{
			if(n>1 && n<=60)
			{
				System.out.println("Interest is 9.2%");
			}
			else
			{
				System.out.println("Interest 8.3");
			}
		}
		if(args[0].equalsIgnoreCase("Female"))
		{
			if(n>1 && n<=58)
			{
				System.out.println("Interest 8.2");
			}
			else
			{
				System.out.println("Interest 7.6");
			}
		}
	}

}



