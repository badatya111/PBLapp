import java.util.Scanner;


public class CommandLineArg {
	 public static void main(String[] args)
	{
		 int a=args.length;
		if(a==0)
		{
			System.out.println("no value");
		}
		else
		{
			for(int i=0;i<a;i++){
				System.out.println(args[i]);
				if(i==a-1)
					break;
				else{
					System.out.println(" , ");
				}
			}
		}
	}
} 

	/* public static void main(String[] args)
	{
		if(args.length == 0){
			System.out.println("NO value");

		}
		else{
			System.out.println(args[0]+ " , "+args[1]);
		}
	}
}
	*/