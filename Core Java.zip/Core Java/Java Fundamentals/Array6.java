import java.text.MessageFormat;
import java.util.Scanner;


public class Array6 {
	
	public static void main(String[] args){
		
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter number of elements:");
        
        int numberOfElements = scan.nextInt();
        
        System.out.print(MessageFormat.format("Enter {0} {1} ",numberOfElements,"numbers: "));
        
        int [] elements = new int[numberOfElements];
        
        for (int i = 0; i < elements.length; i++) {
        	
            elements[i]=scan.nextInt();
            
            java.util.Arrays.sort(elements);
        }
        System.out.println(java.util.Arrays.toString(elements));
    }

}
