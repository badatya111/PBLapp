
public class Array11 {
	public static void main(String[] args) 
	{
		int[] box = new int[4];
		int[][] box1 = new int[2][2];
		if(args.length!= 4)
		{
			System.out.println("Enter four integers : ");
		}
		else
		{
			for(int i=0; i<box.length; i++)
			{
				box[i] = Integer.parseInt(args[i]);
			}
			int count = 0;
			for(int j= 0; j < box1.length; j++)
			{
				for(int k= 0; k < box1[j].length; k++)
				{
					
							box1[j][k] = box[count];
							count++;
				}
			}
			System.out.println("The given array is: ");
			for(int j= 0; j < box1.length; j++)
			{
				for(int k= 0; k < box1[j].length; k++)
				{
					System.out.print(box1[j][k]+ " ");
				}
				System.out.println();
			}
			for(int j= 0; j < box1.length; j++)
			{
				for(int k= 0; k < box1[j].length; k++)
				{
					int temp = box1[j][k];
					box1[j][k] = box1[j][box1[j].length-1];
					box1[j][box1[j].length-1]=temp;
				}
			}
			System.out.println("The reverse of the array is : ");
		
		for(int j= 0; j < box1.length; j++)
		{
			for(int k= 0; k < box1[j].length; k++)
			{
				System.out.print(box1[j][k]+ " ");
			}
			System.out.println();
		}
	}
}

}


