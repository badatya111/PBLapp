
public class Array1 {
	public static void main(String[] args) {
		
		int [] num =new int[]{10,20,30,40,50,60};
		
		int sum=0;
		
		for(int i=0;i<=num.length;i++)
		{
			sum = sum+num[i];
			
			double average = sum / num.length;
			
			System.out.println("Avarage No"+average);
		}
		
		
	}


}